#!/bin/bash
# Hermes v0.2.1 Startup Script

HERMES_DIR="$(cd "$(dirname "$0")" && pwd)"
source "$HERMES_DIR/hermes/bin/activate"

# Check for Firebase config
if [ ! -f ~/.p2pchat/config.json ]; then
    echo "First time setup detected!"
    echo "Creating config at ~/.p2pchat/"
    mkdir -p ~/.p2pchat
fi

echo "Starting Hermes v0.2.1..."
echo "Commands:"
echo "  hermes              - Start terminal client"
echo "  hermes-server      - Start relay server"
echo "  web-ui              - Start web UI (Flask + WebSocket)"
echo ""

exec "$HERMES_DIR/hermes/bin/hermes" "$@"
