#!/bin/bash
# Hermes v0.2.1 Web UI Startup Script

HERMES_DIR="$(cd "$(dirname "$0")" && pwd)"
source "$HERMES_DIR/hermes/bin/activate"

echo "Starting Hermes Web UI v0.2.1..."
echo "Web UI: http://localhost:8080"
echo "WebSocket: ws://localhost:8081"
exec "$HERMES_DIR/hermes/bin/web-ui" --host 0.0.0.0 --port 8080 --ws-port 8081 "$@"
