#!/bin/bash
# Hermes v0.2.1 Server Startup Script

HERMES_DIR="$(cd "$(dirname "$0")" && pwd)"
source "$HERMES_DIR/hermes/bin/activate"

echo "Starting Hermes Relay Server v0.2.1..."
exec "$HERMES_DIR/hermes/bin/hermes-server" --host 0.0.0.0 --port 7777 "$@"
