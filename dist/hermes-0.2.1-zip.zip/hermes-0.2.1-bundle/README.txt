HERMES v0.2.1
=============
A terminal-first P2P chat app with relay server, Firebase fallback, and Web UI.

QUICK START
----------
1. Run ./start.sh to start the terminal client
2. Run ./start-server.sh to start the relay server (optional)
3. Run ./start-web.sh to start the web UI (optional)

FEATURES
--------
- Direct peer-to-peer messaging (TCP/UDP)
- Firebase fallback transport
- RSA and Fernet encryption
- Real-time WebSocket support
- Channel-based messaging
- File sharing

TERMINAL COMMANDS
-----------------
/help      - Show all commands
/join      - Join a channel
/connect   - Connect to a peer
/peers     - List online peers
/ping      - Ping a peer
/status    - Show connection status
/clear     - Clear messages
/quit      - Exit

FIRST TIME SETUP
-----------------
1. Create a Firebase project at console.firebase.google.com
2. Enable Realtime Database
3. Set database rules (see Firebase setup in README.md)
4. Edit ~/.p2pchat/config.json with your Firebase config

FIREBASE CONFIG EXAMPLE
----------------------
{
  "cloud": {
    "backend": "firebase",
    "enabled": true,
    "project_id": "your-project-id",
    "database_url": "https://your-project.firebaseio.com"
  }
}

LICENSE: MIT
