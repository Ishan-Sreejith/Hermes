import asyncio
import json
import struct
import sys
from p2pchat.protocol import read_message, encode

async def test_sniffing():
    print("Testing protocol sniffing...")
    
    # 1. Test Framed JSON
    msg = {"type": "msg", "body": "hello framed"}
    framed_data = encode(msg)
    
    reader = asyncio.StreamReader()
    reader.feed_data(framed_data)
    reader.feed_eof()
    
    decoded = await read_message(reader)
    print(f"Framed Decoded: {decoded}")
    assert decoded["body"] == "hello framed"
    
    # 2. Test Raw Text (nc)
    raw_data = b"hello raw nc\n"
    
    reader = asyncio.StreamReader()
    reader.feed_data(raw_data)
    reader.feed_eof()
    
    decoded_raw = await read_message(reader)
    print(f"Raw Decoded: {decoded_raw}")
    assert decoded_raw["body"] == "hello raw nc"
    assert decoded_raw["source"] == "nc"
    
    print("Sniffing tests passed!")

if __name__ == "__main__":
    asyncio.run(test_sniffing())
