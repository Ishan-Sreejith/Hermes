import pytest
from p2pchat.protocol import build
from p2pchat.transport import FirebaseTransport
from p2pchat.config import Config, CloudConfig

class DummyIdentity:
    peer_id = "test-peer"
    username = "test-user"

@pytest.mark.asyncio
async def test_message_build_compatibility():
    # Test that building a message produces all fields required by rules
    msg = build(
        type_="msg",
        body="hello",
        from_id="alice",
        from_name="Alice",
        to="bob"
    )
    
    # Required by database.rules.json
    assert "id" in msg
    assert msg["fromId"] == "alice"
    assert msg["fromName"] == "Alice"
    assert msg["to"] == "bob"
    assert msg["text"] == "hello"
    assert msg["ts"] > 0
    assert msg["v"] == 2
    assert "scope" in msg
    assert msg["source"] == "terminal"
    
    # Required for backward/interop compatibility
    assert msg["from_id"] == "alice"
    assert msg["from_name"] == "Alice"
    assert msg["body"] == "hello"

@pytest.mark.asyncio
async def test_path_construction():
    cfg = Config()
    fb = FirebaseTransport(cfg, DummyIdentity())
    
    # Check if we can build a connection or check room logic
    # (Since we're not actually calling the network, we test the logic)
    
    # FirebaseTransport has internal _request, let's mock it if needed
    # but for now we just verify the build logic
    pass
